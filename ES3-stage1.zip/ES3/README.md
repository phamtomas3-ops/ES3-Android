# ES.3 Editor
Android save-file encryption/compression/inspection toolkit. See the master spec. Status: **Stage 1 (foundation)**.
Native `.es3` crypto, decryption, GZip, editor: not implemented yet. Legacy EasySave3: LEGACY COMPATIBILITY: UNVERIFIED.
Build: push to GitHub; Actions produces the debug APK artifact. Local: `gradle :app:assembleDebug` (Gradle 8.10+, JDK 17).
